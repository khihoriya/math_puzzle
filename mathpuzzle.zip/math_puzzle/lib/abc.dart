import 'package:shared_preferences/shared_preferences.dart';

class Gbclass {
  static SharedPreferences? prefs;
  static List<String> Statuslist = [];
}